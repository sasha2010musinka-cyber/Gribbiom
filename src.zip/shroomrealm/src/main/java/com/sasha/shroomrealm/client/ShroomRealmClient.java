package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.client.model.CapstalkerModel;
import com.sasha.shroomrealm.client.model.ColossusModel;
import com.sasha.shroomrealm.client.model.PuffcapModel;
import com.sasha.shroomrealm.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class ShroomRealmClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.PUFFCAP, PuffcapModel::getTexturedModelData);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.CAPSTALKER, CapstalkerModel::getTexturedModelData);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.COLOSSUS, ColossusModel::getTexturedModelData);

        EntityRendererRegistry.register(ModEntities.SPORELING, SporelingRenderer::new);
        EntityRendererRegistry.register(ModEntities.MYCELID, MycelidRenderer::new);
        EntityRendererRegistry.register(ModEntities.GLOW_COW, GlowCowRenderer::new);
        EntityRendererRegistry.register(ModEntities.PUFFCAP, PuffcapRenderer::new);
        EntityRendererRegistry.register(ModEntities.CAPSTALKER, CapstalkerRenderer::new);
        EntityRendererRegistry.register(ModEntities.COLOSSUS, ColossusRenderer::new);
    }
}
