package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.client.model.ColossusModel;
import com.sasha.shroomrealm.entity.ColossusEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class ColossusRenderer extends MobEntityRenderer<ColossusEntity, ColossusModel> {
    private static final Identifier TEXTURE = ShroomRealm.id("textures/entity/colossus.png");

    public ColossusRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new ColossusModel(ctx.getPart(ModModelLayers.COLOSSUS)), 1.6f);
    }

    @Override
    public Identifier getTexture(ColossusEntity entity) { return TEXTURE; }

    @Override
    protected void scale(ColossusEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(1.9f, 1.9f, 1.9f);
    }
}
