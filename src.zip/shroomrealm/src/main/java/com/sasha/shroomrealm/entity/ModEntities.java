package com.sasha.shroomrealm.entity;

import com.sasha.shroomrealm.ShroomRealm;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public class ModEntities {
    public static final EntityType<SporelingEntity> SPORELING = Registry.register(Registries.ENTITY_TYPE,
            ShroomRealm.id("sporeling"),
            FabricEntityTypeBuilder.<SporelingEntity>createMob()
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn)
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(SporelingEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                    .trackRangeBlocks(8)
                    .build());

    public static final EntityType<MycelidEntity> MYCELID = Registry.register(Registries.ENTITY_TYPE,
            ShroomRealm.id("mycelid"),
            FabricEntityTypeBuilder.<MycelidEntity>createMob()
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn)
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(MycelidEntity::new)
                    .dimensions(EntityDimensions.fixed(1.4f, 0.9f))
                    .trackRangeBlocks(8)
                    .build());

    public static final EntityType<GlowCowEntity> GLOW_COW = Registry.register(Registries.ENTITY_TYPE,
            ShroomRealm.id("glow_cow"),
            FabricEntityTypeBuilder.<GlowCowEntity>createMob()
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, GlowCowEntity::canSpawn)
                    .spawnGroup(SpawnGroup.CREATURE)
                    .entityFactory(GlowCowEntity::new)
                    .dimensions(EntityDimensions.fixed(0.9f, 1.4f))
                    .trackRangeBlocks(10)
                    .build());

    public static final EntityType<PuffcapEntity> PUFFCAP = Registry.register(Registries.ENTITY_TYPE,
            ShroomRealm.id("puffcap"),
            FabricEntityTypeBuilder.<PuffcapEntity>createMob()
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, PuffcapEntity::canSpawn)
                    .spawnGroup(SpawnGroup.CREATURE)
                    .entityFactory(PuffcapEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.6f))
                    .trackRangeBlocks(8)
                    .build());

    public static final EntityType<CapstalkerEntity> CAPSTALKER = Registry.register(Registries.ENTITY_TYPE,
            ShroomRealm.id("capstalker"),
            FabricEntityTypeBuilder.<CapstalkerEntity>createMob()
                    .spawnRestriction(SpawnRestriction.Location.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MobEntity::canMobSpawn)
                    .spawnGroup(SpawnGroup.MONSTER)
                    .entityFactory(CapstalkerEntity::new)
                    .dimensions(EntityDimensions.fixed(0.9f, 2.4f))
                    .trackRangeBlocks(10)
                    .build());

    public static final EntityType<ColossusEntity> COLOSSUS = Registry.register(Registries.ENTITY_TYPE,
            ShroomRealm.id("colossus"),
            FabricEntityTypeBuilder.<ColossusEntity>create(SpawnGroup.MONSTER, ColossusEntity::new)
                    .dimensions(EntityDimensions.fixed(2.6f, 5.4f))
                    .trackRangeBlocks(16)
                    .fireImmune()
                    .build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(SPORELING, SporelingEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MYCELID, MycelidEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(GLOW_COW, GlowCowEntity.createCowAttributes());
        FabricDefaultAttributeRegistry.register(PUFFCAP, PuffcapEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(CAPSTALKER, CapstalkerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(COLOSSUS, ColossusEntity.createAttributes());
    }
}
