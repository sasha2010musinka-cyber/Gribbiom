package com.sasha.shroomrealm.item;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

import java.util.function.Supplier;

public enum ModToolMaterials implements ToolMaterial {
    MYCELIUM(2, 650, 6.5f, 2.0f, 16, () -> Ingredient.ofItems(ModItems.SPORE_CRYSTAL)),
    FANG(3, 2200, 8.0f, 5.0f, 22, () -> Ingredient.ofItems(ModItems.SHROOM_HEART));

    private final int level;
    private final int durability;
    private final float speed;
    private final float damage;
    private final int enchantability;
    private final Supplier<Ingredient> repair;

    ModToolMaterials(int level, int durability, float speed, float damage, int enchantability, Supplier<Ingredient> repair) {
        this.level = level;
        this.durability = durability;
        this.speed = speed;
        this.damage = damage;
        this.enchantability = enchantability;
        this.repair = repair;
    }

    @Override public int getDurability() { return durability; }
    @Override public float getMiningSpeedMultiplier() { return speed; }
    @Override public float getAttackDamage() { return damage; }
    @Override public int getMiningLevel() { return level; }
    @Override public int getEnchantability() { return enchantability; }
    @Override public Ingredient getRepairIngredient() { return repair.get(); }
}
