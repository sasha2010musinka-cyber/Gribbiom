package com.sasha.shroomrealm.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** ПКМ: взрыв спор в точке, куда смотришь (до 20 блоков). Урон и яд всем, кроме тебя. */
public class SporeStaffItem extends Item {
    public SporeStaffItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!(world instanceof ServerWorld sw)) {
            return TypedActionResult.success(stack);
        }
        HitResult hit = user.raycast(20.0, 0.0f, false);
        Vec3d pos = hit.getPos();
        Box box = new Box(pos.x - 4, pos.y - 2, pos.z - 4, pos.x + 4, pos.y + 4, pos.z + 4);
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, box, en -> en != user && en.isAlive())) {
            e.damage(sw.getDamageSources().indirectMagic(user, user), 7.0f);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1), user);
        }
        for (int i = 0; i < 24; i++) {
            double a = i * Math.PI * 2.0 / 24.0;
            sw.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR, pos.x + Math.cos(a) * 3.0, pos.y + 0.3, pos.z + Math.sin(a) * 3.0, 3, 0.2, 0.3, 0.2, 0.02);
        }
        sw.spawnParticles(ParticleTypes.CLOUD, pos.x, pos.y + 0.5, pos.z, 20, 1.0, 0.5, 1.0, 0.02);
        sw.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0f, 1.2f);
        user.getItemCooldownManager().set(this, 100);
        stack.damage(1, user, p -> p.sendToolBreakStatus(hand));
        return TypedActionResult.success(stack, false);
    }
}
