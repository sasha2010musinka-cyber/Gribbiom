package com.sasha.shroomrealm.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;

/** Каждый удар отравляет и вызывает тошноту. */
public class MyceliumSwordItem extends SwordItem {
    public MyceliumSwordItem(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 0), attacker);
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 100, 0), attacker);
        return super.postHit(stack, target, attacker);
    }
}
