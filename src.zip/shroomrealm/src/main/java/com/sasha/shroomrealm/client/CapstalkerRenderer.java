package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.client.model.CapstalkerModel;
import com.sasha.shroomrealm.entity.CapstalkerEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class CapstalkerRenderer extends MobEntityRenderer<CapstalkerEntity, CapstalkerModel> {
    private static final Identifier TEXTURE = ShroomRealm.id("textures/entity/capstalker.png");

    public CapstalkerRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new CapstalkerModel(ctx.getPart(ModModelLayers.CAPSTALKER)), 0.5f);
    }

    @Override
    public Identifier getTexture(CapstalkerEntity entity) { return TEXTURE; }
}
