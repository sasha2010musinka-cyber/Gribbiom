package com.sasha.shroomrealm.client.model;

import net.minecraft.client.model.*;

/** Автогенерировано: геометрия и раскладка UV совпадают с текстурой. */
public class CapstalkerParts {
    public static TexturedModelData create() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();
        ModelPartData legR = root.addChild("legR", ModelPartBuilder.create().uv(106, 0).cuboid(-1.5f, 0f, -1.5f, 3f, 12f, 3f), ModelTransform.pivot(-2f, 12f, 0f));
        ModelPartData legL = root.addChild("legL", ModelPartBuilder.create().uv(0, 19).cuboid(-1.5f, 0f, -1.5f, 3f, 12f, 3f), ModelTransform.pivot(2f, 12f, 0f));
        ModelPartData torso = root.addChild("torso", ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -14f, -2.5f, 8f, 14f, 5f), ModelTransform.pivot(0f, 12f, 0f));
        ModelPartData head = torso.addChild("head", ModelPartBuilder.create().uv(12, 19).cuboid(-3f, -6f, -3f, 6f, 6f, 6f), ModelTransform.pivot(0f, -14f, 0f));
        ModelPartData cap = head.addChild("cap", ModelPartBuilder.create().uv(26, 0).cuboid(-7f, -4f, -7f, 14f, 4f, 14f), ModelTransform.pivot(0f, -6f, 0f));
        ModelPartData capTop = cap.addChild("capTop", ModelPartBuilder.create().uv(36, 19).cuboid(-4f, -3f, -4f, 8f, 3f, 8f), ModelTransform.pivot(0f, -4f, 0f));
        ModelPartData armR = torso.addChild("armR", ModelPartBuilder.create().uv(82, 0).cuboid(-1.5f, 0f, -1.5f, 3f, 14f, 3f), ModelTransform.pivot(-5.5f, -13f, 0f));
        ModelPartData armL = torso.addChild("armL", ModelPartBuilder.create().uv(94, 0).cuboid(-1.5f, 0f, -1.5f, 3f, 14f, 3f), ModelTransform.pivot(5.5f, -13f, 0f));
        return TexturedModelData.of(modelData, 128, 64);
    }
}
