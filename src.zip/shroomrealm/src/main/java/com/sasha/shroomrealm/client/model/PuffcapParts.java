package com.sasha.shroomrealm.client.model;

import net.minecraft.client.model.*;

/** Автогенерировано: геометрия и раскладка UV совпадают с текстурой. */
public class PuffcapParts {
    public static TexturedModelData create() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();
        ModelPartData body = root.addChild("body", ModelPartBuilder.create().uv(40, 0).cuboid(-3f, -6f, -3f, 6f, 6f, 6f), ModelTransform.pivot(0f, 20f, 0f));
        ModelPartData cap = body.addChild("cap", ModelPartBuilder.create().uv(0, 0).cuboid(-5f, -4f, -5f, 10f, 4f, 10f), ModelTransform.pivot(0f, -6f, 0f));
        ModelPartData capTop = cap.addChild("capTop", ModelPartBuilder.create().uv(0, 14).cuboid(-3f, -2f, -3f, 6f, 2f, 6f), ModelTransform.pivot(0f, -4f, 0f));
        ModelPartData legL = root.addChild("legL", ModelPartBuilder.create().uv(24, 14).cuboid(-1f, 0f, -1f, 2f, 4f, 2f), ModelTransform.pivot(2f, 20f, 0f));
        ModelPartData legR = root.addChild("legR", ModelPartBuilder.create().uv(32, 14).cuboid(-1f, 0f, -1f, 2f, 4f, 2f), ModelTransform.pivot(-2f, 20f, 0f));
        return TexturedModelData.of(modelData, 64, 64);
    }
}
