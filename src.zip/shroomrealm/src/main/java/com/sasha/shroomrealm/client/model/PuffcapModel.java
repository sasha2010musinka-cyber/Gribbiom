package com.sasha.shroomrealm.client.model;

import com.sasha.shroomrealm.entity.PuffcapEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** Анимации: прыжки при ходьбе, покачивание шляпки, поворот головы. */
public class PuffcapModel extends SinglePartEntityModel<PuffcapEntity> {
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart cap;
    private final ModelPart legL;
    private final ModelPart legR;

    public PuffcapModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.cap = this.body.getChild("cap");
        this.legL = root.getChild("legL");
        this.legR = root.getChild("legR");
    }

    public static TexturedModelData getTexturedModelData() {
        return PuffcapParts.create();
    }

    @Override
    public ModelPart getPart() { return this.root; }

    @Override
    public void setAngles(PuffcapEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.getPart().traverse().forEach(ModelPart::resetTransform);
        float hop = Math.abs(MathHelper.sin(limbAngle * 0.9f)) * limbDistance;
        this.body.pivotY = 20.0f - hop * 5.0f;
        this.body.yaw = headYaw * 0.017453292f * 0.6f;
        this.legL.pitch = MathHelper.cos(limbAngle * 0.9f) * 1.2f * limbDistance;
        this.legR.pitch = -MathHelper.cos(limbAngle * 0.9f) * 1.2f * limbDistance;
        this.cap.roll = MathHelper.sin(animationProgress * 0.1f) * 0.08f + MathHelper.sin(limbAngle * 0.9f) * 0.12f * limbDistance;
        this.cap.pitch = MathHelper.cos(animationProgress * 0.07f) * 0.04f;
    }
}
