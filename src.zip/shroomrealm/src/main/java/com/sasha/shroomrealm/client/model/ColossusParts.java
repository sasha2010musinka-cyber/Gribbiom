package com.sasha.shroomrealm.client.model;

import net.minecraft.client.model.*;

/** Автогенерировано: геометрия и раскладка UV совпадают с текстурой. */
public class ColossusParts {
    public static TexturedModelData create() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();
        ModelPartData legR = root.addChild("legR", ModelPartBuilder.create().uv(48, 26).cuboid(-2.5f, 0f, -2.5f, 5f, 12f, 5f), ModelTransform.pivot(-4f, 12f, 0f));
        ModelPartData legL = root.addChild("legL", ModelPartBuilder.create().uv(68, 26).cuboid(-2.5f, 0f, -2.5f, 5f, 12f, 5f), ModelTransform.pivot(4f, 12f, 0f));
        ModelPartData torso = root.addChild("torso", ModelPartBuilder.create().uv(80, 0).cuboid(-6f, -16f, -4f, 12f, 16f, 8f), ModelTransform.pivot(0f, 12f, 0f));
        ModelPartData head = torso.addChild("head", ModelPartBuilder.create().uv(88, 26).cuboid(-4f, -8f, -4f, 8f, 8f, 8f), ModelTransform.pivot(0f, -16f, 0f));
        ModelPartData cap = head.addChild("cap", ModelPartBuilder.create().uv(0, 0).cuboid(-10f, -6f, -10f, 20f, 6f, 20f), ModelTransform.pivot(0f, -8f, 0f));
        ModelPartData capTop = cap.addChild("capTop", ModelPartBuilder.create().uv(0, 50).cuboid(-6f, -4f, -6f, 12f, 4f, 12f), ModelTransform.pivot(0f, -6f, 0f));
        ModelPartData armR = torso.addChild("armR", ModelPartBuilder.create().uv(0, 26).cuboid(-3f, -2f, -3f, 6f, 18f, 6f), ModelTransform.pivot(-9f, -14f, 0f));
        ModelPartData armL = torso.addChild("armL", ModelPartBuilder.create().uv(24, 26).cuboid(-3f, -2f, -3f, 6f, 18f, 6f), ModelTransform.pivot(9f, -14f, 0f));
        return TexturedModelData.of(modelData, 128, 128);
    }
}
