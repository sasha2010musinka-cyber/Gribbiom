package com.sasha.shroomrealm.item;

import com.sasha.shroomrealm.entity.ColossusEntity;
import com.sasha.shroomrealm.entity.ModEntities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** ПКМ по блоку в Грибном измерении призывает босса. */
public class ColossusTotemItem extends Item {
    public ColossusTotemItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        if (!(world instanceof ServerWorld sw)) {
            return ActionResult.SUCCESS;
        }
        PlayerEntity player = ctx.getPlayer();
        if (!sw.getRegistryKey().equals(SporeCatalystItem.REALM)) {
            if (player != null) player.sendMessage(Text.translatable("message.shroomrealm.totem_wrong_world"), true);
            return ActionResult.FAIL;
        }
        BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
        ColossusEntity boss = ModEntities.COLOSSUS.create(sw);
        if (boss == null) return ActionResult.FAIL;
        boss.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, player != null ? player.getYaw() + 180.0f : 0.0f, 0.0f);
        sw.spawnEntity(boss);
        sw.playSound(null, pos, SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 1.0f, 0.8f);
        if (player == null || !player.getAbilities().creativeMode) {
            ctx.getStack().decrement(1);
        }
        return ActionResult.SUCCESS;
    }
}
