package com.sasha.shroomrealm.entity;

import com.sasha.shroomrealm.item.ModItems;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/** Светящаяся грибная корова: миской даёт Светящееся рагу, доится вёдрами, размножается пшеницей. */
public class GlowCowEntity extends CowEntity {
    public GlowCowEntity(EntityType<? extends CowEntity> type, World world) {
        super(type, world);
    }

    public static boolean canSpawn(EntityType<GlowCowEntity> type, WorldAccess world, SpawnReason reason, BlockPos pos, Random random) {
        return world.getBlockState(pos.down()).isOf(Blocks.MYCELIUM)
                || world.getBlockState(pos.down()).isOf(Blocks.GRASS_BLOCK);
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (stack.isOf(Items.BOWL) && !this.isBaby()) {
            player.playSound(SoundEvents.ENTITY_MOOSHROOM_MILK, 1.0f, 1.0f);
            ItemStack result = ItemUsage.exchangeStack(stack, player, new ItemStack(ModItems.GLOW_STEW));
            player.setStackInHand(hand, result);
            return ActionResult.success(this.getWorld().isClient);
        }
        return super.interactMob(player, hand);
    }

    @Override
    public CowEntity createChild(ServerWorld world, PassiveEntity mate) {
        return ModEntities.GLOW_COW.create(world);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient && this.random.nextInt(12) == 0) {
            this.getWorld().addParticle(ParticleTypes.SPORE_BLOSSOM_AIR,
                    this.getParticleX(0.6), this.getRandomBodyY(), this.getParticleZ(0.6), 0.0, -0.02, 0.0);
        }
    }
}
