package com.sasha.shroomrealm.world;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.entity.ModEntities;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

/** Измерение использует биом «грибные поля»; мобов и руду добавляем в этот биом. */
public class ModWorldgen {
    public static void register() {
        var mushroom = BiomeSelectors.includeByKey(BiomeKeys.MUSHROOM_FIELDS);

        BiomeModifications.addSpawn(mushroom, SpawnGroup.MONSTER, ModEntities.SPORELING, 40, 2, 4);
        BiomeModifications.addSpawn(mushroom, SpawnGroup.MONSTER, ModEntities.MYCELID, 25, 1, 2);
        BiomeModifications.addSpawn(mushroom, SpawnGroup.MONSTER, ModEntities.CAPSTALKER, 16, 1, 2);
        BiomeModifications.addSpawn(mushroom, SpawnGroup.CREATURE, ModEntities.GLOW_COW, 12, 3, 5);
        BiomeModifications.addSpawn(mushroom, SpawnGroup.CREATURE, ModEntities.PUFFCAP, 14, 2, 4);

        RegistryKey<PlacedFeature> ore = RegistryKey.of(RegistryKeys.PLACED_FEATURE, ShroomRealm.id("glowcap_ore"));
        BiomeModifications.addFeature(mushroom, GenerationStep.Feature.UNDERGROUND_ORES, ore);
    }
}
