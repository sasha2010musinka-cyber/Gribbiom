package com.sasha.shroomrealm.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.EnumSet;

/**
 * Мицелиевый колосс - босс измерения.
 * Фаза 1: удары и топот (удар по земле с задержкой, виден по анимации).
 * Фаза 2 (меньше 50% здоровья): ярость, призыв спорлингов, ядовитая аура.
 */
public class ColossusEntity extends HostileEntity {
    private static final TrackedData<Integer> SLAM = DataTracker.registerData(ColossusEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private final ServerBossBar bossBar = new ServerBossBar(this.getDisplayName(), BossBar.Color.PURPLE, BossBar.Style.PROGRESS);
    private int slamCooldown = 60;
    private int summonTimer = 0;
    private boolean enraged = false;

    public ColossusEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 200;
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.27)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(SLAM, 0);
    }

    public int getSlam() { return this.dataTracker.get(SLAM); }

    public void setSlam(int value) { this.dataTracker.set(SLAM, value); }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new SlamGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.7));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        this.goalSelector.add(6, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, false));
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        this.bossBar.setPercent(this.getHealth() / this.getMaxHealth());
        if (this.slamCooldown > 0) this.slamCooldown--;

        if (!this.enraged && this.getHealth() <= this.getMaxHealth() * 0.5f) {
            this.enraged = true;
            this.bossBar.setColor(BossBar.Color.RED);
            this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.34);
            this.playSound(SoundEvents.ENTITY_RAVAGER_ROAR, 3.0f, 0.6f);
            this.summonSporelings(3);
        }
        if (this.enraged) {
            this.summonTimer++;
            if (this.summonTimer >= 200) {
                this.summonTimer = 0;
                int nearby = this.getWorld().getEntitiesByClass(SporelingEntity.class, this.getBoundingBox().expand(20.0), e -> true).size();
                if (nearby < 5) this.summonSporelings(2);
            }
            if (this.age % 60 == 0) {
                for (PlayerEntity p : this.getWorld().getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(10.0), pl -> pl.isAlive())) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 80, 0));
                }
            }
        }
    }

    private void summonSporelings(int count) {
        if (!(this.getWorld() instanceof ServerWorld sw)) return;
        for (int i = 0; i < count; i++) {
            SporelingEntity s = ModEntities.SPORELING.create(sw);
            if (s != null) {
                s.refreshPositionAndAngles(this.getX() + this.random.nextInt(7) - 3, this.getY(), this.getZ() + this.random.nextInt(7) - 3, this.random.nextFloat() * 360.0f, 0.0f);
                s.setTarget(this.getTarget());
                sw.spawnEntity(s);
            }
        }
    }

    /** Удар по земле: урон и подброс игроков рядом. */
    private void doSlam() {
        if (!(this.getWorld() instanceof ServerWorld sw)) return;
        for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(7.0, 2.0, 7.0), pl -> pl.isAlive())) {
            p.damage(sw.getDamageSources().mobAttack(this), 12.0f);
            p.takeKnockback(1.4, this.getX() - p.getX(), this.getZ() - p.getZ());
            p.addVelocity(0.0, 0.7, 0.0);
            p.velocityModified = true;
        }
        for (int i = 0; i < 32; i++) {
            double a = i * Math.PI * 2.0 / 32.0;
            sw.spawnParticles(ParticleTypes.POOF, this.getX() + Math.cos(a) * 4.0, this.getY() + 0.2, this.getZ() + Math.sin(a) * 4.0, 2, 0.1, 0.1, 0.1, 0.02);
        }
        sw.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR, this.getX(), this.getY() + 0.5, this.getZ(), 60, 2.5, 0.5, 2.5, 0.05);
        this.playSound(SoundEvents.ENTITY_WARDEN_ATTACK_IMPACT, 3.0f, 0.7f);
    }

    @Override
    public boolean tryAttack(Entity target) {
        boolean hit = super.tryAttack(target);
        if (hit && target instanceof LivingEntity living) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1));
        }
        return hit;
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) { return false; }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public void setCustomName(Text name) {
        super.setCustomName(name);
        this.bossBar.setName(this.getDisplayName());
    }

    @Override
    public void onDeath(DamageSource source) {
        super.onDeath(source);
        this.bossBar.clearPlayers();
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.ENTITY_RAVAGER_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ENTITY_RAVAGER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_RAVAGER_DEATH; }

    private static class SlamGoal extends Goal {
        private final ColossusEntity boss;

        SlamGoal(ColossusEntity boss) {
            this.boss = boss;
            this.setControls(EnumSet.of(Goal.Control.MOVE, Goal.Control.LOOK));
        }

        @Override
        public boolean canStart() {
            LivingEntity t = this.boss.getTarget();
            return t != null && t.isAlive() && this.boss.squaredDistanceTo(t) < 36.0
                    && this.boss.slamCooldown <= 0 && this.boss.getSlam() == 0;
        }

        @Override
        public boolean shouldContinue() {
            return this.boss.getSlam() != 0;
        }

        @Override
        public void start() {
            this.boss.setSlam(20);
            this.boss.slamCooldown = this.boss.enraged ? 80 : 130;
            this.boss.getNavigation().stop();
        }

        @Override
        public void tick() {
            LivingEntity t = this.boss.getTarget();
            if (t != null) this.boss.getLookControl().lookAt(t, 30.0f, 30.0f);
            int s = this.boss.getSlam();
            if (s > 0) {
                s--;
                this.boss.setSlam(s);
                if (s == 0) {
                    this.boss.doSlam();
                    this.boss.setSlam(-10);
                }
            } else if (s < 0) {
                this.boss.setSlam(s + 1);
            }
        }
    }
}
