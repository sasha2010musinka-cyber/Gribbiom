package com.sasha.shroomrealm.block;

import com.sasha.shroomrealm.ShroomRealm;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public class ModBlocks {
    public static final Block GLOWCAP = new Block(FabricBlockSettings.create()
            .mapColor(MapColor.ORANGE)
            .strength(1.5f)
            .luminance(s -> 13)
            .sounds(BlockSoundGroup.AMETHYST_BLOCK));

    public static void register() {
        Registry.register(Registries.BLOCK, ShroomRealm.id("glowcap"), GLOWCAP);
    }
}
