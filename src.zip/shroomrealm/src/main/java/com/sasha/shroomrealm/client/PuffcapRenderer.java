package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.client.model.PuffcapModel;
import com.sasha.shroomrealm.entity.PuffcapEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class PuffcapRenderer extends MobEntityRenderer<PuffcapEntity, PuffcapModel> {
    private static final Identifier TEXTURE = ShroomRealm.id("textures/entity/puffcap.png");

    public PuffcapRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PuffcapModel(ctx.getPart(ModModelLayers.PUFFCAP)), 0.3f);
    }

    @Override
    public Identifier getTexture(PuffcapEntity entity) { return TEXTURE; }
}
