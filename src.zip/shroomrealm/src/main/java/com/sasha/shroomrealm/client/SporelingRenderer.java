package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.entity.SporelingEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class SporelingRenderer extends BipedEntityRenderer<SporelingEntity, ZombieEntityModel<SporelingEntity>> {
    private static final Identifier TEXTURE = ShroomRealm.id("textures/entity/sporeling.png");

    public SporelingRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new ZombieEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 0.5f);
    }

    @Override
    public Identifier getTexture(SporelingEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(SporelingEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(0.9f, 0.9f, 0.9f);
    }
}
