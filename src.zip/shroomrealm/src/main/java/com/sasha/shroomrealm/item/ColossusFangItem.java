package com.sasha.shroomrealm.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;

/** Награда за босса: лечит владельца при ударе, сильно отравляет цель. */
public class ColossusFangItem extends SwordItem {
    public ColossusFangItem(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        attacker.heal(2.0f);
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1), attacker);
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1), attacker);
        if (attacker.getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR, target.getX(), target.getBodyY(0.5), target.getZ(), 14, 0.3, 0.4, 0.3, 0.03);
        }
        return super.postHit(stack, target, attacker);
    }
}
