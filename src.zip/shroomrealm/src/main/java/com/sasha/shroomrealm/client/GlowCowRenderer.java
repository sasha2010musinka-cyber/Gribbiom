package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.entity.GlowCowEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.CowEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class GlowCowRenderer extends MobEntityRenderer<GlowCowEntity, CowEntityModel<GlowCowEntity>> {
    private static final Identifier TEXTURE = ShroomRealm.id("textures/entity/glow_cow.png");

    public GlowCowRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new CowEntityModel<>(ctx.getPart(EntityModelLayers.COW)), 0.7f);
    }

    @Override
    public Identifier getTexture(GlowCowEntity entity) {
        return TEXTURE;
    }
}
