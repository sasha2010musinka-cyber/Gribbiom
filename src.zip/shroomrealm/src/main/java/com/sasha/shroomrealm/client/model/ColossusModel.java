package com.sasha.shroomrealm.client.model;

import com.sasha.shroomrealm.entity.ColossusEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** Анимации: тяжёлая ходьба, дыхание, замах обеими руками и удар по земле (SLAM). */
public class ColossusModel extends SinglePartEntityModel<ColossusEntity> {
    private final ModelPart root;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart cap;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart legR;
    private final ModelPart legL;

    public ColossusModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = this.torso.getChild("head");
        this.cap = this.head.getChild("cap");
        this.armR = this.torso.getChild("armR");
        this.armL = this.torso.getChild("armL");
        this.legR = root.getChild("legR");
        this.legL = root.getChild("legL");
    }

    public static TexturedModelData getTexturedModelData() {
        return ColossusParts.create();
    }

    @Override
    public ModelPart getPart() { return this.root; }

    @Override
    public void setAngles(ColossusEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.getPart().traverse().forEach(ModelPart::resetTransform);
        this.head.yaw = headYaw * 0.017453292f * 0.6f;
        this.head.pitch = headPitch * 0.017453292f * 0.6f;
        this.legR.pitch = MathHelper.cos(limbAngle * 0.5f) * 1.0f * limbDistance;
        this.legL.pitch = MathHelper.cos(limbAngle * 0.5f + 3.1415927f) * 1.0f * limbDistance;
        this.torso.roll = MathHelper.sin(limbAngle * 0.5f) * 0.06f * limbDistance;
        float breath = MathHelper.sin(animationProgress * 0.08f) * 0.04f;
        this.armR.pitch = MathHelper.cos(limbAngle * 0.5f + 3.1415927f) * 0.7f * limbDistance;
        this.armL.pitch = MathHelper.cos(limbAngle * 0.5f) * 0.7f * limbDistance;
        this.armR.roll = 0.08f + breath;
        this.armL.roll = -0.08f - breath;
        this.cap.roll = breath;

        int slam = entity.getSlam();
        if (slam > 0) {
            float raise = 1.0f - slam / 20.0f;
            float a = -2.8f * raise;
            this.armR.pitch = a;
            this.armL.pitch = a;
            this.armR.roll = 0.0f;
            this.armL.roll = 0.0f;
            this.torso.pitch = -0.25f * raise;
        } else if (slam < 0) {
            float fall = -slam / 10.0f;
            float a = -2.8f * fall;
            this.armR.pitch = a;
            this.armL.pitch = a;
            this.armR.roll = 0.0f;
            this.armL.roll = 0.0f;
            this.torso.pitch = 0.35f * (1.0f - fall);
        }
    }
}
