package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.ShroomRealm;
import net.minecraft.client.render.entity.model.EntityModelLayer;

public class ModModelLayers {
    public static final EntityModelLayer PUFFCAP = new EntityModelLayer(ShroomRealm.id("puffcap"), "main");
    public static final EntityModelLayer CAPSTALKER = new EntityModelLayer(ShroomRealm.id("capstalker"), "main");
    public static final EntityModelLayer COLOSSUS = new EntityModelLayer(ShroomRealm.id("colossus"), "main");
}
