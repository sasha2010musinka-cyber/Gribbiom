package com.sasha.shroomrealm.item;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.block.ModBlocks;
import com.sasha.shroomrealm.entity.ModEntities;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.StewItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Rarity;

public class ModItems {
    public static final Item SPORE_CATALYST = new SporeCatalystItem(new FabricItemSettings().maxDamage(8));
    public static final Item GLOW_STEW = new StewItem(new FabricItemSettings().maxCount(1).food(
            new FoodComponent.Builder().hunger(6).saturationModifier(0.6f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100), 1.0f)
                    .build()));
    public static final Item GLOWCAP = new BlockItem(ModBlocks.GLOWCAP, new FabricItemSettings());

    public static final Item SPORE_CRYSTAL = new Item(new FabricItemSettings());
    public static final Item MYCELIUM_SWORD = new MyceliumSwordItem(ModToolMaterials.MYCELIUM, 3, -2.4f, new FabricItemSettings());
    public static final Item MYCELIUM_AXE = new SporeAxeItem(ModToolMaterials.MYCELIUM, 5.0f, -3.0f, new FabricItemSettings());
    public static final Item SPORE_STAFF = new SporeStaffItem(new FabricItemSettings().maxDamage(120));
    public static final Item COLOSSUS_TOTEM = new ColossusTotemItem(new FabricItemSettings().maxCount(1).rarity(Rarity.RARE));
    public static final Item SHROOM_HEART = new Item(new FabricItemSettings().maxCount(16).rarity(Rarity.EPIC).food(
            new FoodComponent.Builder().hunger(4).saturationModifier(1.0f).alwaysEdible()
                    .statusEffect(new StatusEffectInstance(StatusEffects.HEALTH_BOOST, 12000, 3), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 600, 1), 1.0f)
                    .statusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 6000, 0), 1.0f)
                    .build()));
    public static final Item COLOSSUS_FANG = new ColossusFangItem(ModToolMaterials.FANG, 3, -2.2f,
            new FabricItemSettings().rarity(Rarity.EPIC).fireproof());

    public static final Item SPORELING_EGG = new SpawnEggItem(ModEntities.SPORELING, 0xC83232, 0xF2E6D0, new FabricItemSettings());
    public static final Item MYCELID_EGG = new SpawnEggItem(ModEntities.MYCELID, 0x503270, 0x3CE6C8, new FabricItemSettings());
    public static final Item GLOW_COW_EGG = new SpawnEggItem(ModEntities.GLOW_COW, 0x1E5A6E, 0x5AFFE6, new FabricItemSettings());
    public static final Item PUFFCAP_EGG = new SpawnEggItem(ModEntities.PUFFCAP, 0xEB8C3C, 0xFFF0D2, new FabricItemSettings());
    public static final Item CAPSTALKER_EGG = new SpawnEggItem(ModEntities.CAPSTALKER, 0x6E3CA0, 0x82FFDC, new FabricItemSettings());
    public static final Item COLOSSUS_EGG = new SpawnEggItem(ModEntities.COLOSSUS, 0xAA2332, 0xF5EBD7, new FabricItemSettings());

    private static void reg(String name, Item item) {
        Registry.register(Registries.ITEM, ShroomRealm.id(name), item);
    }

    public static void register() {
        reg("spore_catalyst", SPORE_CATALYST);
        reg("glow_stew", GLOW_STEW);
        reg("glowcap", GLOWCAP);
        reg("spore_crystal", SPORE_CRYSTAL);
        reg("mycelium_sword", MYCELIUM_SWORD);
        reg("mycelium_axe", MYCELIUM_AXE);
        reg("spore_staff", SPORE_STAFF);
        reg("colossus_totem", COLOSSUS_TOTEM);
        reg("shroom_heart", SHROOM_HEART);
        reg("colossus_fang", COLOSSUS_FANG);
        reg("sporeling_spawn_egg", SPORELING_EGG);
        reg("mycelid_spawn_egg", MYCELID_EGG);
        reg("glow_cow_spawn_egg", GLOW_COW_EGG);
        reg("puffcap_spawn_egg", PUFFCAP_EGG);
        reg("capstalker_spawn_egg", CAPSTALKER_EGG);
        reg("colossus_spawn_egg", COLOSSUS_EGG);

        Registry.register(Registries.ITEM_GROUP, ShroomRealm.id("main"), FabricItemGroup.builder()
                .icon(() -> new ItemStack(SPORE_CATALYST))
                .displayName(Text.translatable("itemGroup.shroomrealm.main"))
                .entries((ctx, entries) -> {
                    entries.add(SPORE_CATALYST);
                    entries.add(GLOW_STEW);
                    entries.add(GLOWCAP);
                    entries.add(SPORE_CRYSTAL);
                    entries.add(MYCELIUM_SWORD);
                    entries.add(MYCELIUM_AXE);
                    entries.add(SPORE_STAFF);
                    entries.add(COLOSSUS_TOTEM);
                    entries.add(SHROOM_HEART);
                    entries.add(COLOSSUS_FANG);
                    entries.add(SPORELING_EGG);
                    entries.add(MYCELID_EGG);
                    entries.add(GLOW_COW_EGG);
                    entries.add(PUFFCAP_EGG);
                    entries.add(CAPSTALKER_EGG);
                    entries.add(COLOSSUS_EGG);
                })
                .build());
    }
}
