package com.sasha.shroomrealm.client;

import com.sasha.shroomrealm.ShroomRealm;
import com.sasha.shroomrealm.entity.MycelidEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SpiderEntityRenderer;
import net.minecraft.util.Identifier;

public class MycelidRenderer extends SpiderEntityRenderer<MycelidEntity> {
    private static final Identifier TEXTURE = ShroomRealm.id("textures/entity/mycelid.png");

    public MycelidRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(MycelidEntity entity) {
        return TEXTURE;
    }
}
