package com.sasha.shroomrealm.client.model;

import com.sasha.shroomrealm.entity.CapstalkerEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/** Анимации: длинный шаг, качание шляпки, в бою руки вытянуты вперёд и подрагивают. */
public class CapstalkerModel extends SinglePartEntityModel<CapstalkerEntity> {
    private final ModelPart root;
    private final ModelPart torso;
    private final ModelPart head;
    private final ModelPart cap;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart legR;
    private final ModelPart legL;

    public CapstalkerModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = this.torso.getChild("head");
        this.cap = this.head.getChild("cap");
        this.armR = this.torso.getChild("armR");
        this.armL = this.torso.getChild("armL");
        this.legR = root.getChild("legR");
        this.legL = root.getChild("legL");
    }

    public static TexturedModelData getTexturedModelData() {
        return CapstalkerParts.create();
    }

    @Override
    public ModelPart getPart() { return this.root; }

    @Override
    public void setAngles(CapstalkerEntity entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        this.getPart().traverse().forEach(ModelPart::resetTransform);
        this.head.yaw = headYaw * 0.017453292f;
        this.head.pitch = headPitch * 0.017453292f;
        this.legR.pitch = MathHelper.cos(limbAngle * 0.6662f) * 1.3f * limbDistance;
        this.legL.pitch = MathHelper.cos(limbAngle * 0.6662f + 3.1415927f) * 1.3f * limbDistance;
        if (entity.isAttacking()) {
            float shake = MathHelper.sin(animationProgress * 0.9f) * 0.12f;
            this.armR.pitch = -1.55f + shake;
            this.armL.pitch = -1.55f - shake;
            this.torso.pitch = 0.25f;
        } else {
            this.armR.pitch = MathHelper.cos(limbAngle * 0.6662f + 3.1415927f) * 0.9f * limbDistance;
            this.armL.pitch = MathHelper.cos(limbAngle * 0.6662f) * 0.9f * limbDistance;
            this.armR.roll = 0.05f + MathHelper.sin(animationProgress * 0.08f) * 0.04f;
            this.armL.roll = -0.05f - MathHelper.sin(animationProgress * 0.08f) * 0.04f;
        }
        this.cap.roll = MathHelper.sin(animationProgress * 0.1f) * 0.06f;
    }
}
