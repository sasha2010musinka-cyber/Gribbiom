package com.sasha.shroomrealm.item;

import com.sasha.shroomrealm.ShroomRealm;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** ПКМ: переносит в Грибное измерение и обратно (те же X/Z). */
public class SporeCatalystItem extends Item {
    public static final RegistryKey<World> REALM = RegistryKey.of(RegistryKeys.WORLD, ShroomRealm.id("mushroom_realm"));

    public SporeCatalystItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!(world instanceof ServerWorld from) || !(user instanceof ServerPlayerEntity player)) {
            return TypedActionResult.success(stack);
        }
        MinecraftServer server = from.getServer();
        boolean inRealm = from.getRegistryKey().equals(REALM);
        ServerWorld target = inRealm ? server.getOverworld() : server.getWorld(REALM);
        if (target == null) {
            player.sendMessage(Text.translatable("message.shroomrealm.missing"), true);
            return TypedActionResult.fail(stack);
        }

        BlockPos pos = player.getBlockPos();
        int x = pos.getX();
        int z = pos.getZ();
        int y = target.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);

        // дымок спор на старте
        from.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR, player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.6, 0.8, 0.6, 0.02);

        // площадка 3x3 под ногами, если там нет твёрдой земли
        Block pad = inRealm ? Blocks.DIRT : Blocks.MYCELIUM;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos b = new BlockPos(x + dx, y - 1, z + dz);
                if (!target.getBlockState(b).isSolidBlock(target, b)) {
                    target.setBlockState(b, pad.getDefaultState());
                }
            }
        }

        player.teleport(target, x + 0.5, y, z + 0.5, player.getYaw(), player.getPitch());
        target.playSound(null, x + 0.5, y, z + 0.5, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 0.6f);
        target.spawnParticles(ParticleTypes.SPORE_BLOSSOM_AIR, x + 0.5, y + 1.0, z + 0.5, 40, 0.6, 0.8, 0.6, 0.02);

        player.getItemCooldownManager().set(this, 60);
        stack.damage(1, player, p -> p.sendToolBreakStatus(hand));
        return TypedActionResult.success(stack, false);
    }
}
