package com.sasha.shroomrealm;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class ShroomRealm implements ModInitializer {
    public static final String MOD_ID = "shroomrealm";

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        com.sasha.shroomrealm.block.ModBlocks.register();
        com.sasha.shroomrealm.entity.ModEntities.register();
        com.sasha.shroomrealm.item.ModItems.register();
        com.sasha.shroomrealm.world.ModWorldgen.register();
    }
}
